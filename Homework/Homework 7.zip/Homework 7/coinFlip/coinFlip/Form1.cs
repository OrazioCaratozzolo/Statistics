namespace coinFlip
{
    public partial class Form1 : Form
    {
        public Bitmap bIstogram;
        public Graphics gInstogram;
        public Bitmap b, b1;
        public Graphics g, g1;
        public Random r = new Random();

        private Rectangle rectangle;

        public Pen PenTrajectoryAbsolute = new Pen(Color.White, 1);
        public Pen PenTrajectoryRelative = new Pen(Color.Red, 1);
        public Pen PenTrajectoryRelativeNormalized = new Pen(Color.LightGreen, 1);

        public Pen PenRectangle = new Pen(Color.White, 2);
        public Pen PenRectangleIsto = new Pen(Color.Red, 2);
        public Pen PenRectangleIstoNormalized = new Pen(Color.LightGreen, 2);

        public Pen PenTrajectoryIsto = new Pen(Color.LightGreen, 1);
        public Pen PenTrajectoryIstoRelative = new Pen(Color.White, 1);
        public Pen PenTrajectoryIstoRelativeNormalized = new Pen(Color.Orange, 1);

        int trialCount = 100;
        
        public Form1()
        {
            InitializeComponent();
        }
        private void btnGenerate_Click(object sender, EventArgs e)
        {
            b = new Bitmap(this.pictureBox1.Width, this.pictureBox1.Height); //make new bitmap
            g = Graphics.FromImage(b); //pass the new bitmap as a argument
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            g.Clear(Color.Black);

            b1 = new Bitmap(pictureBox2.Width, pictureBox2.Height);
            g1 = Graphics.FromImage(b1);
            g1.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            g1.Clear(Color.Black);


            int numberOfTrajectory = 30;
            int totalAttempts = trialCount * numberOfTrajectory;
            int absoluteFrequencyCounter = 0;
           
            string interval = this.textBox1.Text;
            string modSuccessProb = textBox2.Text;
            double successProbability = Convert.ToDouble(modSuccessProb);
            int intervalInstogram = Convert.ToInt32(interval);

            double relativeFrequencyCounter = 0;
            double normalizedRelativeFrequency = 0;
            double minX = 0;
            double minY = 0;
            double maxX = trialCount;
            double maxY = trialCount;

            List<int> listSuc = new List<int>();
            List<int> sucDistr = new List<int>();
            List<int> disPoint = new List<int>();
            List<int> finalList = new List<int>();

            rectangle = new Rectangle(0, 0, this.b1.Width, this.b1.Height);
            Rectangle rectangleVirtualWindow = new Rectangle(0, 0, this.b.Width - 100, this.b.Height);
            Rectangle rectangleVirtualWindowInsotgram = new Rectangle(this.b.Width - 100, 0, this.b.Width, this.b.Height);
            g.DrawRectangle(PenRectangle, rectangleVirtualWindow);
            g.DrawRectangle(PenRectangle, rectangleVirtualWindowInsotgram);
            g1.DrawRectangle(PenRectangle, rectangle);


            if (successProbability < 0.0)
            {
                successProbability = 0.0;
            }

            if (successProbability >= trialCount)
            {
                successProbability = trialCount-1;
            }
            if (intervalInstogram < 1)
            {
                intervalInstogram = 1;
            }
            successProbability = successProbability / trialCount;
            List<Point> listYValue = new List<Point>();
            //Absolute distribution
            for (int i = 1; i <= numberOfTrajectory; i++)
            {
                List<Point> punti = new List<Point>();
                int y = 0;
                int xDevice = FromXRealToXVirtual(0, minX, maxX, 0, rectangleVirtualWindow.Width);
                int yDevice = FromYRealToYVirtual(0, minY, maxY, 0, rectangleVirtualWindow.Height);
                Point tempPoint = new Point(xDevice, yDevice);
                punti.Add(tempPoint);
                punti.Clear();
                for (int x = 1; x <= trialCount; x++)
                {
                    double rand = r.NextDouble();
                    if (rand < successProbability)
                    {
                        y += 1;
                        listSuc.Add(x);
                    }
                    xDevice = FromXRealToXVirtual(x, minX, maxX, 0, rectangleVirtualWindow.Width);
                    yDevice = FromYRealToYVirtual(y, minY, maxY, 0, rectangleVirtualWindow.Height);
                    tempPoint = new Point(xDevice, yDevice);
                    punti.Add(tempPoint);

                }
                g.DrawLines(PenTrajectoryAbsolute, punti.ToArray());
                if (y > 0)
                {
                    double dTC = Convert.ToDouble(trialCount);
                    double success = Convert.ToDouble(y);
                    absoluteFrequencyCounter = absoluteFrequencyCounter + y;
                    listYValue.Add(tempPoint);

                }
            }
            if (successProbability > 0)
            {
                int maxYcoordinate = 0;
                double minYcoordinate = 1000000000;
                for (int h = 0; h < listYValue.Count; h++)
                {
                    if (listYValue[h].Y >= maxYcoordinate)
                    {
                        maxYcoordinate = listYValue[h].Y;
                    }
                    if (listYValue[h].Y <= minYcoordinate)
                    {
                        minYcoordinate = listYValue[h].Y;
                    }
                }

                double dim = (maxYcoordinate - minYcoordinate) / intervalInstogram;
                double first_element = minYcoordinate;
                double last_element = minYcoordinate + dim;

                for (int j = 1; j <= intervalInstogram; j++)
                {
                    int count = 0;
                    for (int k = 0; k < listYValue.Count; k++)
                    {
                        if (listYValue[k].Y >= first_element && listYValue[k].Y <= last_element)
                        {
                            count += 1;
                        }
                    }
                    Rectangle rect_insto = new Rectangle(listYValue[0].X, Convert.ToInt32(first_element),
                          FromXRealToXVirtual(count, minX, maxX, 0, rectangleVirtualWindowInsotgram.Width), Convert.ToInt32(dim));
                    g.DrawRectangle(PenTrajectoryIsto, rect_insto);
                    g.FillRectangle(Brushes.Red, rect_insto);
                    first_element = last_element + 0.01;
                    last_element = last_element + dim + 0.01;
                }
            }
            relativeFrequencyCounter = (Convert.ToDouble(absoluteFrequencyCounter) / Convert.ToDouble(totalAttempts));
            normalizedRelativeFrequency = Math.Round(absoluteFrequencyCounter / (Math.Sqrt(absoluteFrequencyCounter)), 2);
            this.pictureBox1.Image = b;
            //FUNZIONE INTERARRIVI
            finalList=interArrivals(listSuc,sucDistr,disPoint);
            int maxtemp = findMax(disPoint);
            SolidBrush new_brush = new SolidBrush(Color.FromArgb(128, Color.DarkViolet));
            SolidBrush new_brush_border = new SolidBrush(Color.FromArgb(150, Color.LightGreen));
            int start = rectangle.Left;
            for(int m= 0; m<finalList.Count; m++)
            {
                int newheight = FromXRealToXVirtual(Convert.ToDouble(finalList[m]), 0.0, Convert.ToDouble(maxtemp),0,(rectangle.Height));
                Rectangle rect_insto1 = new Rectangle(start, rectangle.Y + (rectangle.Height - finalList[m]),25, finalList[m]);
                start += 25;
                g1.DrawRectangle(new Pen(new_brush_border, 2), rect_insto1);
                g1.FillRectangle(new_brush, rect_insto1);
            }
            pictureBox2.Image = b1;
        }

        private int find_max(List<Point> list)
        {
            int max = 0;
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].Y > max)
                {
                    max = list[i].Y;
                }
            }
            return max + 1;
        }
        public int FromXRealToXVirtual(double x, double minX, double maxX,int left, int w)
        {
            if(maxX-minX == 0)
            {
                return 0;
            }
            return (int)(w * (x - minX) / (maxX - minX));
        }
        public int FromYRealToYVirtual(double y, double minY, double maxY, int top, int h)
        {
            if(maxY-minY == 0)
            {
                return 0;
            }
            return (int)(h-h * (y - minY) / (maxY - minY));
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnRelFreq_Click(object sender, EventArgs e)
        {
            b = new Bitmap(pictureBox1.Width, pictureBox1.Height); //make new bitmap
            g = Graphics.FromImage(b); //pass the new bitmap as a argument
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            g.Clear(Color.Black);
            b1 = new Bitmap(pictureBox2.Width, pictureBox2.Height);
            g1 = Graphics.FromImage(b1);
            g1.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            g1.Clear(Color.Black);

            int trialCount = 100;
            int numberOfTrajectory = 30;
            int totalAttempts = trialCount * numberOfTrajectory;
            int absoluteFrequencyCounter = 0;

            string interval = textBox1.Text;
            string modSuccessProb = textBox2.Text;
            double successProbability = Convert.ToDouble(modSuccessProb);
            int intervalInstogram = Convert.ToInt32(interval);
            double normalizedRelativeFrequency = 0;
            double relativeFrequencyTotalCounter = 0;
            double minX = 0;
            double minY = 0;
            double maxX = trialCount;
            double maxY = trialCount;
            List<int> listSuc = new List<int>();
            List<int> sucDistr = new List<int>();
            List<int> disPoint = new List<int>();
            List<int> finalList = new List<int>();

            rectangle = new Rectangle(0, 0, this.b1.Width, this.b1.Height);
            g1.DrawRectangle(PenRectangle, rectangle);
            Rectangle rectangleVirtualWindow = new Rectangle(0, 0, this.b.Width - 100, this.b.Height);
            Rectangle rectangleVirtualWindowInsotgram = new Rectangle(this.b.Width - 100, 0, this.b.Width, this.b.Height);
            g.DrawRectangle(PenRectangleIsto, rectangleVirtualWindow);
            g.DrawRectangle(PenRectangleIsto, rectangleVirtualWindowInsotgram);

            if (successProbability < 0.0)
            {
                successProbability = 0.0;
            }

            if (successProbability >= trialCount)
            {
                successProbability = trialCount-1;
            }
            if (intervalInstogram < 1)
            {
                intervalInstogram = 1;
            }
            successProbability = successProbability / trialCount;
            List<Point> listYValue = new List<Point>();
            //Relative distribution
            for (int i = 1; i <= numberOfTrajectory; i++)
            {
                List<Point> punti = new List<Point>();
                List<Point> ListaTemp = new List<Point>();
                int xDevice = FromXRealToXVirtual(0, minX, maxX, rectangleVirtualWindow.Left, rectangleVirtualWindow.Width);
                int yDevice = FromYRealToYVirtual(0, minY, maxY, rectangleVirtualWindow.Top, rectangleVirtualWindow.Height);
                double y = 0;
                double changedCoordinateY;
                int finalCoordinateY;
                Point tempPoint = new Point(xDevice, yDevice);
                punti.Add(tempPoint);
                for (int x = 1; x <= trialCount; x++)
                {
                    double rand = r.NextDouble();
                    if (rand < successProbability)
                    {
                        y += 1;
                        listSuc.Add(x);
                    }
                    changedCoordinateY = (y / x) * 100;
                    finalCoordinateY = Convert.ToInt32(changedCoordinateY);
                    xDevice = FromXRealToXVirtual(x, minX, maxX, rectangleVirtualWindow.Left, rectangleVirtualWindow.Width);
                    yDevice = FromYRealToYVirtual(finalCoordinateY, minY, maxY, rectangleVirtualWindow.Top, rectangleVirtualWindow.Height);
                    tempPoint = new Point(xDevice, yDevice);
                    punti.Add(tempPoint);
                }
                g.DrawLines(PenTrajectoryRelative, punti.ToArray());
                if (y > 0)
                {
                    double dTC = Convert.ToDouble(trialCount);
                    double success = y;
                    absoluteFrequencyCounter = (absoluteFrequencyCounter + Convert.ToInt32(y));
                    listYValue.Add(tempPoint);
                }
            }
            if (successProbability > 0)
            {
                int maxYcoordinate = 0;
                double minYcoordinate = 1000000000;
                for (int h = 0; h < listYValue.Count; h++)
                {
                    if (listYValue[h].Y >= maxYcoordinate)
                    {
                        maxYcoordinate = listYValue[h].Y;
                    }
                    if (listYValue[h].Y <= minYcoordinate)
                    {
                        minYcoordinate = listYValue[h].Y;
                    }
                }

                double dim = (maxYcoordinate - minYcoordinate) / intervalInstogram;
                double first_element = minYcoordinate;
                double last_element = minYcoordinate + dim;

                for (int j = 1; j <= intervalInstogram; j++)
                {
                    int count = 0;
                    for (int k = 0; k < listYValue.Count; k++)
                    {
                        if (listYValue[k].Y >= first_element && listYValue[k].Y <= last_element)
                        {
                            count += 1;
                        }
                    }
                    Rectangle rect_insto = new Rectangle(listYValue[0].X, Convert.ToInt32(first_element),
                       FromXRealToXVirtual(count, minX, maxX, rectangleVirtualWindow.Left, rectangleVirtualWindow.Width), Convert.ToInt32(dim));
                    g.DrawRectangle(PenTrajectoryIstoRelative, rect_insto);
                    g.FillRectangle(Brushes.LightGreen, rect_insto);
                    first_element = last_element + 0.01;
                    last_element = last_element + dim + 0.01;
                }
            }
            relativeFrequencyTotalCounter = (Convert.ToDouble(absoluteFrequencyCounter) / Convert.ToDouble(totalAttempts));
            normalizedRelativeFrequency = Math.Round(absoluteFrequencyCounter / Math.Sqrt(absoluteFrequencyCounter), 2);
            pictureBox1.Image = b;
            finalList = interArrivals(listSuc, sucDistr, disPoint);
            int maxtemp = findMax(disPoint);
            SolidBrush new_brush = new SolidBrush(Color.FromArgb(128, Color.DarkViolet));
            SolidBrush new_brush_border = new SolidBrush(Color.FromArgb(150, Color.LightGreen));
            int start = rectangle.Left;
            for (int m = 0; m < finalList.Count; m++)
            {
                int newheight = FromXRealToXVirtual(Convert.ToDouble(finalList[m]), 0.0, Convert.ToDouble(maxtemp), 0, (rectangle.Height));
                Rectangle rect_insto1 = new Rectangle(start, rectangle.Y + (rectangle.Height - finalList[m]), 25, finalList[m]);
                start += 25;
                g1.DrawRectangle(new Pen(new_brush_border, 2), rect_insto1);
                g1.FillRectangle(new_brush, rect_insto1);
            }
            pictureBox2.Image = b1;
        }

        private void btnNormFreq_Click(object sender, EventArgs e)
        {
            b = new Bitmap(pictureBox1.Width, pictureBox1.Height); //make new bitmap
            g = Graphics.FromImage(b); //pass the new bitmap as a argument
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            g.Clear(Color.Black);
            b1 = new Bitmap(pictureBox2.Width, pictureBox2.Height);
            g1 = Graphics.FromImage(b1);
            g1.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            g1.Clear(Color.Black);

            int trialCount = 100;
            int numberOfTrajectory = 30;
            int totalAttempts = trialCount * numberOfTrajectory;
            int absoluteFrequencyCounter = 0;

            string interval = textBox1.Text;
            string modSuccessProb = textBox2.Text;
            double successProbability = Convert.ToDouble(modSuccessProb);
            int intervalInstogram = Convert.ToInt32(interval);

            double normalizedRelativeFrequency = 0;
            double relativeFrequencyTotalCounter = 0;
            double minX = 0;
            double minY = 0;
            double maxX = (double)trialCount;
            double maxY = (double)trialCount;
            List<int> listSuc = new List<int>();
            List<int> sucDistr = new List<int>();
            List<int> disPoint = new List<int>();
            List<int> finalList = new List<int>();

            rectangle = new Rectangle(0, 0, this.b1.Width, this.b1.Height);
            g1.DrawRectangle(PenRectangle, rectangle);
            Rectangle rectangleVirtualWindow = new Rectangle(0, 0, this.b.Width - 100, this.b.Height);
            Rectangle rectangleVirtualWindowInsotgram = new Rectangle(this.b.Width - 100, 0, this.b.Width, this.b.Height);
            g.DrawRectangle(PenRectangleIstoNormalized, rectangleVirtualWindow);
            g.DrawRectangle(PenRectangleIstoNormalized, rectangleVirtualWindowInsotgram);

            if (successProbability < 0.0)
            {
                successProbability = 0.0;
                textBox2.Text = "0";
            }

            if (successProbability > trialCount)
            {
                successProbability = trialCount-1;
                textBox2.Text = "1";
            }
            if (intervalInstogram < 1)
            {
                intervalInstogram = 1;
            }
            successProbability = successProbability / trialCount;

            List<Point> listYValue = new List<Point>();
            //Normalized Relative distribution
            for (int i = 1; i <= numberOfTrajectory; i++)
            {
                List<Point> punti = new List<Point>();
                List<Point> ListaTemp = new List<Point>();
                double y = 0;
                int verified = 0;

                double changedCoordinateY;
                int finalCoordinateY;
                int xDevice = FromXRealToXVirtual(0, minX, maxX, rectangleVirtualWindow.Left, rectangleVirtualWindow.Width);
                int yDevice = FromYRealToYVirtual(0, minY, maxY, rectangleVirtualWindow.Top, rectangleVirtualWindow.Height);
                Point tempPoint = new Point(xDevice, yDevice);
                punti.Add(tempPoint);
                for (int x = 1; x <= trialCount; x++)
                {
                    double rand = r.NextDouble();
                    if (rand < successProbability)
                    {
                        y += 1;
                        verified = verified + 1;
                        listSuc.Add(x);

                    }
                    if (verified == 0)
                    {
                        changedCoordinateY = 0;
                    }
                    else
                    {
                        changedCoordinateY = (y / Math.Sqrt(verified)) * 10;
                    }
                    finalCoordinateY = Convert.ToInt32(changedCoordinateY);
                    xDevice = FromXRealToXVirtual(x, minX, maxX, rectangleVirtualWindow.Left, rectangleVirtualWindow.Width);
                    yDevice = FromYRealToYVirtual(finalCoordinateY, minY, maxY, rectangleVirtualWindow.Top, rectangleVirtualWindow.Height);
                    tempPoint = new Point(xDevice, yDevice);
                    punti.Add(tempPoint);
                }
                g.DrawLines(PenTrajectoryRelativeNormalized, punti.ToArray());
                if (y > 0)
                {
                    double dTC = Convert.ToDouble(trialCount);
                    double success = y;
                    absoluteFrequencyCounter = absoluteFrequencyCounter + Convert.ToInt32(y);
                    listYValue.Add(tempPoint);
                }
            }
            if (successProbability > 0)
            {
                int maxYcoordinate = 0;
                double minYcoordinate = 1000000000;
                for (int h = 0; h < listYValue.Count; h++)
                {
                    if (listYValue[h].Y >= maxYcoordinate)
                    {
                        maxYcoordinate = listYValue[h].Y;
                    }
                    if (listYValue[h].Y <= minYcoordinate)
                    {
                        minYcoordinate = listYValue[h].Y;
                    }
                }

                double dim = (maxYcoordinate - minYcoordinate) / intervalInstogram;
                double first_element = minYcoordinate;
                double last_element = minYcoordinate + dim;

                for (int j = 1; j <= intervalInstogram; j++)
                {
                    int count = 0;
                    for (int k = 0; k < listYValue.Count; k++)
                    {
                        if (listYValue[k].Y >= first_element && listYValue[k].Y <= last_element)
                        {
                            count += 1;
                        }
                    }
                    Rectangle rect_insto = new Rectangle(listYValue[0].X, Convert.ToInt32(first_element),
                         FromXRealToXVirtual(count, minX, maxX, rectangleVirtualWindow.Left, rectangleVirtualWindow.Width), Convert.ToInt32(dim));
                    g.DrawRectangle(PenTrajectoryIstoRelativeNormalized, rect_insto);
                    g.FillRectangle(Brushes.DarkViolet, rect_insto);
                    first_element = last_element + 0.01;
                    last_element = last_element + dim + 0.01;
                }
            }
            relativeFrequencyTotalCounter = (Convert.ToDouble(absoluteFrequencyCounter) / Convert.ToDouble(totalAttempts));
            normalizedRelativeFrequency = Math.Round(absoluteFrequencyCounter / Math.Sqrt(absoluteFrequencyCounter), 2);
            pictureBox1.Image = b;
            finalList=interArrivals(listSuc, sucDistr, disPoint);
            int maxtemp = findMax(disPoint);
            SolidBrush new_brush = new SolidBrush(Color.FromArgb(128, Color.DarkViolet));
            SolidBrush new_brush_border = new SolidBrush(Color.FromArgb(150, Color.LightGreen));
            int start = rectangle.Left;
            for (int m = 0; m < finalList.Count; m++)
            {
                int newheight = FromXRealToXVirtual(Convert.ToDouble(finalList[m]), 0.0, Convert.ToDouble(maxtemp), 0, (rectangle.Height));
                Rectangle rect_insto1 = new Rectangle(start, rectangle.Y + (rectangle.Height - finalList[m]), 25, finalList[m]);
                start += 25;
                g1.DrawRectangle(new Pen(new_brush_border, 2), rect_insto1);
                g1.FillRectangle(new_brush, rect_insto1);
            }
            pictureBox2.Image = b1;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        int max = 0;
        int findMax(List<int> list)
        {
            for(int i=0; i<list.Count; i++)
            {
                if (list[i] > max)
                {
                    max = list[i];
                }
            }
            return max;
        }

        List<int> interArrivals(List<int> listSuc, List<int> sucDistr, List<int> disPoint)
        {
            int contSuc = 0;
            int max = 0;
            for (int i = 1; i < listSuc.Count; i++)
            {
               
                    sucDistr.Add((listSuc[i] - listSuc[(i - 1)]));
                
            }
            max = findMax(sucDistr);
            for(int j=1; j<=max; j++)
            {
                for(int k=0; k<sucDistr.Count; k++)
                {
                    if (j == sucDistr[k])
                    {
                        contSuc++;
                    }
                }
                disPoint.Add(contSuc);
                contSuc = 0;
            }
            return disPoint;
        }

    }

}