using System.Security.Cryptography;

namespace csv_parser
{
    internal  class Program
    {
        
      
        
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
       
        static void Main()
        {
    
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());
            //fillRecord(); 
            
        }
        public static void addRecord(string name, int age, char sex, string filepath)
        {
            try
            {
                using (System.IO.StreamWriter file = new System.IO.StreamWriter(@filepath, true))
                {
                    file.WriteLine(name + "," + age + "," + sex);
                }
            }
            catch(Exception ex)
            {
                throw new ApplicationException("This program did an oopsie : ",ex);
            }
        }

        public static void fillRecord()
        {
            int m = 0, f = 0;
            string[] name = new string[10];
            int[] age = new int[10];
            char[] sex = new char[10];
            string[] maleNames = new string[10] { "aaron", "abdul", "abe", "abel", "abraham", "adam", "adan", "adolfo", "adolph", "adrian" };
            string[] femaleNames = new string[4] { "abby", "abigail", "adele", "adrian" };
            Random randomGender = new Random();
            Random randomAge = new Random();
            
            for (int i = 0; i < name.Length; i++)
            {
                if (randomGender.Next(0, 2) == 1)
                {
                    name[i] = maleNames[m];
                    sex[i] = 'M';
                    age[i] = randomAge.Next(18, 30);
                    m++;
                }
                else
                {
                    name[i] = femaleNames[f];
                    sex[i] = 'F';
                    age[i] = randomAge.Next(18, 30);
                    f++;
                }
            }

            for(int i = 0; i < name.Length; i++)
            {
                addRecord(name[i], age[i], sex[i], "parser.csv");
            }
            
        }
    }
}