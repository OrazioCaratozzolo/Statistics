using System.Net.Cache;
using System.Security.Cryptography.X509Certificates;

namespace read_CSV_C
{
    public partial class Form1 : Form
    {
        Person[] person = new Person[10];

        public Form1()
        {
            InitializeComponent();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            dgvData.DataSource = LoadCSV(textBox1.Text);
        }


        public List<Person> LoadCSV(string csvFile)
        {
            var query = from l in File.ReadAllLines(csvFile)
                        let data = l.Split(',')
                        select new Person
                        {
                            Name = data[0],
                            Age = int.Parse(data[1]),
                            Sex = char.Parse(data[2])
                        };
            person = query.ToArray();
            return query.ToList();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
          OpenFileDialog dlg = new OpenFileDialog();
            dlg.ShowDialog();
            textBox1.Text = dlg.FileName;
        }

        private void rtbStat_TextChanged(object sender, EventArgs e)
        {
         
        }

        private void btnCalcolate_Click(object sender, EventArgs e)
        {
            int m = 0, f = 0;
            for(int i=0; i<person.Length; i++)
            {
                if(person[i].Sex == 'M')
                {
                    m++;
                }
                else
                {
                    f++;
                }
            }
            rtbStat.AppendText("There are " + m*10 + "% male\n" + "There are "+f*10+ "% female\n");
        }
    }

    public class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public char Sex { get; set; }
    }
   
 }