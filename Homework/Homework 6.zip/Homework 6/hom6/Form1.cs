using System.Diagnostics;
using System.Text;

namespace hom6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private List<elem> lista_totale = new List<elem>();
        private int totalRow = -1;
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btLoad_Click(object sender, EventArgs e)
        {
            var parsedData = new List<string[]>();
            using (var sr = new StreamReader("path to csv file"))
            {
                string line;
                while((line = sr.ReadLine()) != null)
                {
                    string[] row = line.Split(';');
                    parsedData.Add(row);
                    totalRow++;
                }
            }
            dgvDataCsv.ColumnCount = 2;
            for(int i=0; i < 2; i++)
            {
                var sb = new StringBuilder(parsedData[0][i]);
                dgvDataCsv.Columns[i].Name = sb.ToString();
            }
            foreach (string[] row in parsedData)
            {
                dgvDataCsv.Rows.Add(row);
            }
            dgvDataCsv.Rows.Remove(dgvDataCsv.Rows[0]);
        }

        private void btCalculate_Click(object sender, EventArgs e)
        {
            double mean, variance;
            int number_of_sample = Convert.ToInt32(this.tbNumberSampleSet.Text);
            int set_of_sample = Convert.ToInt32(this.tbNumberOfTime.Text);

            if(number_of_sample >= totalRow)
            {
                number_of_sample = totalRow-2;
                this.tbNumberSampleSet.Text = number_of_sample.ToString();
            }
            fill_list(lista_totale);
            mean = mean_population(lista_totale);
            variance = variance_population(lista_totale, mean);

            this.tbMeanPopulation.Text = mean.ToString() + "cm";
            this.tbPopulationVariance.Text = variance.ToString();

            sampling(lista_totale, number_of_sample, set_of_sample);
        }

        void fill_list(List<elem> list)
        {
            string column = this.tbColumn.Text;
            string string_height;
            string string_quantinty;
            for(int i=0; i<dgvDataCsv.ColumnCount; i++)
            {
                if (dgvDataCsv.Columns[i].Name == column)
                {
                    for(int j=0; j < totalRow; j++)
                    {
                        string_height = (string)(dgvDataCsv[i, j].Value);
                        string_quantinty = (string)(dgvDataCsv[i + 1, j].Value);
                        elem el = new elem(double.Parse(string_height), Convert.ToInt32(string_quantinty));
                        lista_totale.Add(el);
                    }
                }
            }
        }

        double mean_population(List<elem> list)
        {
            double mean;
            double temp_sum = 0;
            for(int i =0; i<list.Count; i++)
            {
                temp_sum = temp_sum / list.Count;
            }
            mean = temp_sum / list.Count;
            return mean;
        }

        double variance_population(List<elem> list, double mean)
        {
            double variance;
            double sum_temp = 0;
            int i = 0;
            for(i=0; i<list.Count; i++)
            {
                double temp_height = list[i].getHeight();
                sum_temp = sum_temp + (Math.Pow((temp_height-mean),2));
            }
            variance = sum_temp / list.Count;
            return variance;
        }

        void sampling(List<elem>list, int n_elem,int n_set)
        {
            double mean_temp;
            double mean_mean_temp;
            double mean_variance_temp;
            double variance_mean_temp;
            double variance_variance_temp;
            Random rnd = new Random();
            List<elem> mean_of_mean = new List<elem>();
            List<elem> mean_of_variance = new List<elem>();
            for(int i=0; i<n_elem; i++)
            {
                List<elem> list_temp = new List<elem>();
                for(int j=0; j<n_elem; j++)
                {
                    int num = rnd.Next(0,list.Count);
                    list_temp.Add(list[num]);
                }
                mean_temp = mean_population(list_temp);
                elem el = new elem(mean_temp, 1);
                mean_of_mean.Add(el);
                elem elem = new elem(variance_population(list_temp, mean_temp), 1);
                mean_of_variance.Add(elem);
            }
            mean_mean_temp = mean_population(mean_of_mean);
            mean_variance_temp = mean_population(mean_of_variance);
            variance_mean_temp = variance_population(mean_of_mean, mean_mean_temp);
            variance_variance_temp = variance_population(mean_of_variance, mean_population(mean_of_variance));

            this.tbMeanMean.Text = mean_mean_temp.ToString();
            this.tbMeanVariance.Text = mean_variance_temp.ToString();
            this.tbVarianceMean.Text = variance_mean_temp.ToString();
            this.tbVarianceVariance.Text = variance_variance_temp.ToString();
        }
    }
}

public class elem
{
    double height;
    int quantity;

    public elem(double height, int quantity)
    {
        this.height = height;
        this.quantity = quantity;
    }

    public void setHeight(double height1)
    {
        this.height = height1;
    }

    public void setQuantity(int quantity1)
    {
        this.quantity = quantity1;
    }

    public double getHeight()
    {
        return this.height;
    }

    public int getQuantity()
    {
        return this.quantity;
    }
}