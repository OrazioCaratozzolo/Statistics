﻿namespace hom6
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btLoad = new System.Windows.Forms.Button();
            this.dgvDataCsv = new System.Windows.Forms.DataGridView();
            this.btCalculate = new System.Windows.Forms.Button();
            this.tbNumberSampleSet = new System.Windows.Forms.TextBox();
            this.tbNumberOfTime = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbColumn = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tbMeanPopulation = new System.Windows.Forms.TextBox();
            this.tbPopulationVariance = new System.Windows.Forms.TextBox();
            this.tbMeanMean = new System.Windows.Forms.TextBox();
            this.tbVarianceMean = new System.Windows.Forms.TextBox();
            this.tbMeanVariance = new System.Windows.Forms.TextBox();
            this.tbVarianceVariance = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDataCsv)).BeginInit();
            this.SuspendLayout();
            // 
            // btLoad
            // 
            this.btLoad.Location = new System.Drawing.Point(12, 12);
            this.btLoad.Name = "btLoad";
            this.btLoad.Size = new System.Drawing.Size(94, 29);
            this.btLoad.TabIndex = 0;
            this.btLoad.Text = "Load";
            this.btLoad.UseVisualStyleBackColor = true;
            this.btLoad.Click += new System.EventHandler(this.btLoad_Click);
            // 
            // dgvDataCsv
            // 
            this.dgvDataCsv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDataCsv.Location = new System.Drawing.Point(12, 50);
            this.dgvDataCsv.Name = "dgvDataCsv";
            this.dgvDataCsv.RowHeadersWidth = 51;
            this.dgvDataCsv.RowTemplate.Height = 29;
            this.dgvDataCsv.Size = new System.Drawing.Size(366, 313);
            this.dgvDataCsv.TabIndex = 1;
            // 
            // btCalculate
            // 
            this.btCalculate.Location = new System.Drawing.Point(112, 12);
            this.btCalculate.Name = "btCalculate";
            this.btCalculate.Size = new System.Drawing.Size(94, 29);
            this.btCalculate.TabIndex = 2;
            this.btCalculate.Text = "Calculate";
            this.btCalculate.UseVisualStyleBackColor = true;
            this.btCalculate.Click += new System.EventHandler(this.btCalculate_Click);
            // 
            // tbNumberSampleSet
            // 
            this.tbNumberSampleSet.Location = new System.Drawing.Point(157, 371);
            this.tbNumberSampleSet.Name = "tbNumberSampleSet";
            this.tbNumberSampleSet.Size = new System.Drawing.Size(125, 27);
            this.tbNumberSampleSet.TabIndex = 3;
            // 
            // tbNumberOfTime
            // 
            this.tbNumberOfTime.Location = new System.Drawing.Point(157, 404);
            this.tbNumberOfTime.Name = "tbNumberOfTime";
            this.tbNumberOfTime.Size = new System.Drawing.Size(125, 27);
            this.tbNumberOfTime.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 371);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Sample set number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 407);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Number of time";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(384, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Choose column";
            // 
            // tbColumn
            // 
            this.tbColumn.Location = new System.Drawing.Point(517, 50);
            this.tbColumn.Name = "tbColumn";
            this.tbColumn.Size = new System.Drawing.Size(125, 27);
            this.tbColumn.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(384, 172);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Mean Population";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(384, 203);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(140, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Variance Population";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(384, 239);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(182, 20);
            this.label6.TabIndex = 11;
            this.label6.Text = "Mean of the sample Mean";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(384, 276);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(201, 20);
            this.label7.TabIndex = 12;
            this.label7.Text = "Variance of the sample Mean";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(384, 309);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(201, 20);
            this.label8.TabIndex = 13;
            this.label8.Text = "Mean of the sample Variance";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(384, 343);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(220, 20);
            this.label9.TabIndex = 14;
            this.label9.Text = "Variance of the sample Variance";
            // 
            // tbMeanPopulation
            // 
            this.tbMeanPopulation.Location = new System.Drawing.Point(663, 165);
            this.tbMeanPopulation.Name = "tbMeanPopulation";
            this.tbMeanPopulation.Size = new System.Drawing.Size(125, 27);
            this.tbMeanPopulation.TabIndex = 15;
            // 
            // tbPopulationVariance
            // 
            this.tbPopulationVariance.Location = new System.Drawing.Point(663, 196);
            this.tbPopulationVariance.Name = "tbPopulationVariance";
            this.tbPopulationVariance.Size = new System.Drawing.Size(125, 27);
            this.tbPopulationVariance.TabIndex = 16;
            // 
            // tbMeanMean
            // 
            this.tbMeanMean.Location = new System.Drawing.Point(663, 229);
            this.tbMeanMean.Name = "tbMeanMean";
            this.tbMeanMean.Size = new System.Drawing.Size(125, 27);
            this.tbMeanMean.TabIndex = 17;
            // 
            // tbVarianceMean
            // 
            this.tbVarianceMean.Location = new System.Drawing.Point(663, 269);
            this.tbVarianceMean.Name = "tbVarianceMean";
            this.tbVarianceMean.Size = new System.Drawing.Size(125, 27);
            this.tbVarianceMean.TabIndex = 18;
            // 
            // tbMeanVariance
            // 
            this.tbMeanVariance.Location = new System.Drawing.Point(663, 302);
            this.tbMeanVariance.Name = "tbMeanVariance";
            this.tbMeanVariance.Size = new System.Drawing.Size(125, 27);
            this.tbMeanVariance.TabIndex = 19;
            // 
            // tbVarianceVariance
            // 
            this.tbVarianceVariance.Location = new System.Drawing.Point(663, 335);
            this.tbVarianceVariance.Name = "tbVarianceVariance";
            this.tbVarianceVariance.Size = new System.Drawing.Size(125, 27);
            this.tbVarianceVariance.TabIndex = 20;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tbVarianceVariance);
            this.Controls.Add(this.tbMeanVariance);
            this.Controls.Add(this.tbVarianceMean);
            this.Controls.Add(this.tbMeanMean);
            this.Controls.Add(this.tbPopulationVariance);
            this.Controls.Add(this.tbMeanPopulation);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbColumn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbNumberOfTime);
            this.Controls.Add(this.tbNumberSampleSet);
            this.Controls.Add(this.btCalculate);
            this.Controls.Add(this.dgvDataCsv);
            this.Controls.Add(this.btLoad);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDataCsv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btLoad;
        private DataGridView dgvDataCsv;
        private Button btCalculate;
        private TextBox tbNumberSampleSet;
        private TextBox tbNumberOfTime;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox tbColumn;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private TextBox tbMeanPopulation;
        private TextBox tbPopulationVariance;
        private TextBox tbMeanMean;
        private TextBox tbVarianceMean;
        private TextBox tbMeanVariance;
        private TextBox tbVarianceVariance;
    }
}