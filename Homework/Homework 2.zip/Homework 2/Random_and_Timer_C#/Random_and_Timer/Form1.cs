namespace Random_and_Timer
{
    public partial class Form1 : Form
    {
        int i = 10;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            tmrTimeRemaining.Start();
        }

        private void tmrTimeRemaining_Tick(object sender, EventArgs e)
        {
            if (i > 1)
            {
                lblTimer.Text = i.ToString() + " Seconds Remaining ";
            }
            else if (i == 1)
            {
                lblTimer.Text = i.ToString() + " Second Remaining ";
            }
            else
            {
                tmrTimeRemaining.Stop();
                MessageBox.Show("No more time!", "Too bad", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            }
            i--;
        }

        private void lblTimer_Click(object sender, EventArgs e)
        {
            
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            tmrTimeRemaining.Stop();
            MessageBox.Show("You stopped the timer..");
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            Random myRand = new Random();
            i = myRand.Next(0, 10);
            MessageBox.Show(i.ToString(), "Your random number");
        }
    }
}