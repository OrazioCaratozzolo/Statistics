using System.Security.Cryptography.X509Certificates;

namespace csv_parser
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
           Program.fillRecord();
        }

        private void richTextBoxList_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            
        }

       
    }
}
