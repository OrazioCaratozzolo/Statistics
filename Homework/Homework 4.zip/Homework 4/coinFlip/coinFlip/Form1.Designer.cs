﻿namespace coinFlip
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGenerate = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnRelFreq = new System.Windows.Forms.Button();
            this.btnNormFreq = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.intervalTb = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnGenerate
            // 
            this.btnGenerate.Location = new System.Drawing.Point(404, 15);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(144, 48);
            this.btnGenerate.TabIndex = 0;
            this.btnGenerate.Text = "Generate Absolute frequency";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 89);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(835, 445);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // btnRelFreq
            // 
            this.btnRelFreq.Location = new System.Drawing.Point(591, 15);
            this.btnRelFreq.Name = "btnRelFreq";
            this.btnRelFreq.Size = new System.Drawing.Size(143, 48);
            this.btnRelFreq.TabIndex = 3;
            this.btnRelFreq.Text = "Generate Relative frequency";
            this.btnRelFreq.UseVisualStyleBackColor = true;
            this.btnRelFreq.Click += new System.EventHandler(this.btnRelFreq_Click);
            // 
            // btnNormFreq
            // 
            this.btnNormFreq.Location = new System.Drawing.Point(779, 15);
            this.btnNormFreq.Name = "btnNormFreq";
            this.btnNormFreq.Size = new System.Drawing.Size(160, 48);
            this.btnNormFreq.TabIndex = 4;
            this.btnNormFreq.Text = "Generate Normalized frequency";
            this.btnNormFreq.UseVisualStyleBackColor = true;
            this.btnNormFreq.Click += new System.EventHandler(this.btnNormFreq_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(49, 36);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(109, 27);
            this.textBox2.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(181, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "Probability from 0,1 to 0,9";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // intervalTb
            // 
            this.intervalTb.AutoSize = true;
            this.intervalTb.Location = new System.Drawing.Point(259, 13);
            this.intervalTb.Name = "intervalTb";
            this.intervalTb.Size = new System.Drawing.Size(111, 20);
            this.intervalTb.TabIndex = 11;
            this.intervalTb.Text = "Choose Interval";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(259, 36);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(109, 27);
            this.textBox1.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1275, 546);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.intervalTb);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.btnNormFreq);
            this.Controls.Add(this.btnRelFreq);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnGenerate);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnGenerate;
        private PictureBox pictureBox1;
        private Button btnRelFreq;
        private Button btnNormFreq;
        private TextBox textBox2;
        private Label label1;
        private Label intervalTb;
        private TextBox textBox1;
    }
}