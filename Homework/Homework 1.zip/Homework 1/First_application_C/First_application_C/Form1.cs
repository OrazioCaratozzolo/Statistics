using System.Drawing.Text;
using System.Security.Cryptography.X509Certificates;

namespace First_application_C
{
    public partial class Form1 : Form 
    {
        //Create object in this place to use it inside more functions
        Student Student1 = new Student();
        Student Student2 = new Student();
        public Form1()
        {
            InitializeComponent();
        }
        private void Button2_Click(object sender, EventArgs e)
        {
            //Find the average of the students'votes
            double avg = 0;
            avg = (Student1.vote + Student2.vote) / 2;
            richTextBoxAverage.AppendText("The average of the students' votes is " + avg.ToString() + Environment.NewLine);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            //Find the total age of students
            double total = 0;
            total = Student1.age + Student2.age;
            richTextBoxTotal.AppendText("The sum of the students' age is " + total.ToString() + Environment.NewLine);

        }
        private void button3_Click(object sender, EventArgs e)
        {
            //List of Students
            //Student 1
            Student1.name = "Mario Rossi";
            Student1.vote = 28.2;
            Student1.age = 24;
            //Student 2
            Student2.name = "Luigi Bianchi";
            Student2.vote = 27.5;
            Student2.age = 26;

            //Print data on textBox
            textBox1.AppendText(Student1.name + " "+ Student1.age +" "+ Student1.vote + Environment.NewLine);
            textBox1.AppendText(Student2.name + " " + Student2.age +" "+ Student2.vote + Environment.NewLine);
        }
        private void richTextBoxTotal_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

    }

}