﻿Imports System.Runtime.Intrinsics.X86

Public Class Form1

    'Create object in this place to use it inside more functions
    Dim Student1 As New Student
    Dim Student2 As New Student

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'List of Students

        'Student 1
        Student1.name = "Mario Rossi"
        Student1.vote = 28.2
        Student1.age = 24
        'Student 2
        Student2.name = "Luigi Bianchi"
        Student2.vote = 27.5
        Student2.age = 26

        'Print data on textBox
        TextBox1.AppendText(Student1.name & " " & Student1.age & " " & Student1.vote & Environment.NewLine)
        TextBox1.AppendText(Student2.name & " " & Student2.age & " " & Student2.vote & Environment.NewLine)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        'Find the total age of students
        Dim total As Double = 0
        total = Student1.age + Student2.age
        RichTextBoxTotal.AppendText("The sum of the students' age is " & total.ToString() & Environment.NewLine)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'Find the average of the students'votes
        Dim avg As Double = 0
        avg = (Student1.vote + Student2.vote) / 2
        RichTextBoxAvg.AppendText("The average of the students' votes is " & avg.ToString() & Environment.NewLine)
    End Sub
End Class