﻿Public Class Student

    'Declaration of components
    Public name As String
    Public age As Integer
    Public vote As Double
End Class
