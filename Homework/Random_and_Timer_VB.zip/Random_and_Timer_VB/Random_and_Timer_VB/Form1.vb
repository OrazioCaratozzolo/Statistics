﻿Public Class Form1
    Dim seconds As Integer = 10
    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        tmrTimer.Start()
    End Sub

    Private Sub tmrTimer_Tick(sender As Object, e As EventArgs) Handles tmrTimer.Tick
        If (seconds > 1) Then
            lblSeconds.Text = seconds.ToString() & " Seconds Remaining"
        ElseIf (seconds = 1) Then
            lblSeconds.Text = seconds.ToString() & " Second Remaining"
        Else
            tmrTimer.Stop()
            MessageBox.Show("No more time!", "Too bad", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation)
        End If
        seconds -= 1
    End Sub

    Private Sub btnStop_Click(sender As Object, e As EventArgs) Handles btnStop.Click
        tmrTimer.Stop()
        MessageBox.Show("You stopped the timer..")
    End Sub

    Private Sub btnGenerate_Click(sender As Object, e As EventArgs) Handles btnGenerate.Click
        Dim Myrand As New Random
        seconds = Myrand.Next(1, 10)
        MessageBox.Show("You have generate " & seconds.ToString & " seconds")
    End Sub
End Class
