using System;

namespace wireshark_reading
{
    public partial class dvgData : Form
    {
        
        public dvgData()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.ShowDialog();
            textBox1.Text = dlg.FileName;
        }

        private void btlLoad_Click(object sender, EventArgs e)
        {
            dgvData.DataSource = LoadCSV(textBox1.Text);
        }

        private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public List<Element> LoadCSV(string csvFile)
        {
            Element[] element = new Element[1000];
            var query = from l in File.ReadAllLines(csvFile)
                        let data = l.Split(',')
                        select new Element
                        {
                            Id = data[0],
                            Time = data[1],
                            Source = data[2],
                            Destination = data[3],
                            Protocol = data[4],
                            Length = data[5],
                            Info = data[6],
                        };
            element = query.ToArray();
            return query.ToList();
        }
    }
    public class Element
    {
        public string Id { get; set; }
        public string Time { get; set; }
        public string Source { get; set; }
        public string Destination { get; set; }
        public string Protocol { get; set; }
        public string Length { get; set; }
        public string Info { get; set; }

    }
}