﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace First_application_C
{
    internal class Student
    {
        //Declaration of components 
        public string? name;
        public int age;
        public double vote;
    }
}
